Krishi Mitra ? Core System Package

Contents: runnable web app source, deterministic scheme engine and data, backend tests, runtime requirements, user-facing project docs, judge-readiness research, Phase 2/later-workstream research, and Gemini Argon master prompt.

Excluded: .env/secrets, Git history, caches, bytecode, editor settings, generated artifacts, unrelated GSD tooling, and unused farm_hero.mp4. The two hero videos are included because index.html references them; together they account for most of this archive size.

Run from the extracted package root:
  python -m pip install -r requirements.txt
  python -m backend.web_server
Then open http://127.0.0.1:8000. Add provider keys only to a local, unshared .env file; never send that file to Gemini.

Run tests:
  python -m unittest backend.test_rules backend.test_web_server -v

This is the existing local demo package, not a production deployment. Read the included privacy/security research before exposing it publicly.
